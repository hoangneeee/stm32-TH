#include <stdint.h> // Định nghĩa các kiểu nguyên khác nhau

#include <system_stm32f4xx.h> //This file contains the system clock configuration for
#include <STM32F401RE_StdPeriph_Driver/inc/stm32f401re_gpio.h>
//#include <stm32f401re_gpio.h>

#include <timer.h> // thư viện chứa các hàm cấu hình systick

#include <ucglib/Ucglib.h> // thư viện màn hình

static ucg_t ucg;
int main(void) {
  SystemCoreClockUpdate();
  TimerInit(); // file khởi tạo bộ time systick với chu kì 1ms
  Ucglib4WireSWSPI_begin( & ucg, UCG_FONT_MODE_SOLID);
  ucg_ClearScreen( & ucg); //Xóa màn hình
  ucg_SetFont( & ucg, ucg_font_helvR08_tf); // cài đặt font cho màn hình
  ucg_SetColor( & ucg, 0, 255, 255, 255); // cài đặt mã màu cho bộ 0
  ucg_SetColor( & ucg, 1, 0, 0, 0); // cài đặt mã màu cho bộ 1
  ucg_SetRotate180( & ucg); // xoay màn hình 180 độ
  ucg_DrawString( & ucg, 0, 12, 0, "I love Embedded"); //Ghi chuỗi string ra màn hình
  ucg_DrawString( & ucg, 0, 26, 0, "Programming"); // Ghi chuỗi string ra màn hình
  while (1) {
    processTimerScheduler(); // Proccess event in queue
  }
}
